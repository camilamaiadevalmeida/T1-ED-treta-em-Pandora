#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

//Este módulo concentra as principais bibliotecas, de modo que facilita no momento da implementação
#endif