#ifndef _HEADERS_H_
#define _HEADERS_H_

#include "../arqs/geo.h"
 #include "../arqs/libsgerais.h"
#include "../arqs/svg.h"

#include "../ed/fila.h"
#include "../ed/lista.h"

#include "../objetos/formas.h"










#endif